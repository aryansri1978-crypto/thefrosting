import React from 'react';
import { ArrowRight, MessageCircle } from 'lucide-react';
import Button from './Button';
import { WHATSAPP_NUMBER } from '../constants';
import { motion } from 'framer-motion';

const Hero: React.FC = () => {
  const handleWhatsApp = () => {
    window.open(`https://wa.me/${WHATSAPP_NUMBER}`, '_blank');
  };

  const scrollToMenu = () => {
    document.getElementById('menu')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden bg-warm-50">
      {/* Abstract Background Element */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 0.5, scale: 1 }}
        transition={{ duration: 1.5, ease: "easeOut" }}
        className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 bg-primary-100 rounded-full blur-3xl"
      ></motion.div>
      <motion.div 
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 0.5, scale: 1 }}
        transition={{ duration: 1.5, delay: 0.2, ease: "easeOut" }}
        className="absolute bottom-0 left-0 -ml-20 -mb-20 w-80 h-80 bg-orange-100 rounded-full blur-3xl"
      ></motion.div>

      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
          
          {/* Text Content */}
          <div className="flex-1 text-center lg:text-left">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <span className="inline-block px-4 py-1.5 rounded-full bg-primary-100 text-primary-700 font-semibold text-sm mb-6 uppercase tracking-wider">
                Freshly Home Baked
              </span>
            </motion.div>
            
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-4xl md:text-5xl lg:text-7xl font-bold text-warm-900 leading-tight mb-6"
            >
              Freshly Home Baked <span className="text-primary-500">Cakes & Desserts</span>
            </motion.h1>
            
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-lg md:text-xl text-warm-800 mb-8 max-w-2xl mx-auto lg:mx-0 leading-relaxed opacity-80"
            >
              Custom designer cakes, brownies, truffles, cookies, jar cakes and more. 
              Made with love and premium ingredients.
            </motion.p>
            
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start"
            >
              <Button onClick={scrollToMenu} size="lg" className="group">
                View Menu
                <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
              </Button>
              <Button onClick={handleWhatsApp} variant="outline" size="lg" className="bg-white">
                <MessageCircle className="mr-2" size={20} />
                Order on WhatsApp
              </Button>
            </motion.div>
          </div>

          {/* Image Content */}
          <div className="flex-1 w-full max-w-xl lg:max-w-none">
            <div className="relative">
              {/* Main Image */}
              <motion.div 
                initial={{ opacity: 0, scale: 0.9, rotate: 0 }}
                animate={{ opacity: 1, scale: 1, rotate: 2 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="relative rounded-2xl overflow-hidden shadow-2xl transform transition-transform duration-500 hover:rotate-0 aspect-square"
              >
                <img 
                  src="https://picsum.photos/id/292/800/800" 
                  alt="Delicious chocolate brownie stack" 
                  className="object-cover w-full h-full"
                />
                {/* Floating Badge */}
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.8 }}
                  className="absolute bottom-6 left-6 bg-white/90 backdrop-blur px-6 py-4 rounded-xl shadow-lg"
                >
                  <p className="text-sm font-semibold text-gray-500">Bestseller</p>
                  <p className="text-lg font-bold text-warm-900">Fudge Brownies</p>
                </motion.div>
              </motion.div>
              
              {/* Secondary Image */}
              <motion.div 
                initial={{ opacity: 0, x: 20, y: 20 }}
                animate={{ opacity: 1, x: 0, y: 0 }}
                transition={{ duration: 0.8, delay: 0.5 }}
                className="absolute -bottom-10 -right-4 w-2/3 rounded-2xl overflow-hidden shadow-xl border-4 border-white transform -rotate-3 aspect-video hidden md:block"
              >
                 <img 
                  src="https://picsum.photos/id/1080/600/400" 
                  alt="Strawberries and cream" 
                  className="object-cover w-full h-full"
                />
              </motion.div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Hero;