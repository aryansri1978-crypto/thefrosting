import React from 'react';
import Button from './Button';
import { WHATSAPP_NUMBER } from '../constants';
import { Palette, Calendar, MessageSquare } from 'lucide-react';
import { motion } from 'framer-motion';

const CustomOrders: React.FC = () => {
  const handleWhatsApp = () => {
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=Hi, I would like to discuss a custom cake order.`, '_blank');
  };

  return (
    <section id="custom" className="py-20 bg-white overflow-hidden">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8 }}
          className="bg-gradient-to-br from-warm-900 to-warm-800 rounded-3xl p-8 md:p-12 lg:p-16 text-white relative overflow-hidden shadow-2xl"
        >
          
          {/* Decorative Circles */}
          <div className="absolute top-0 right-0 -mr-20 -mt-20 w-80 h-80 bg-white opacity-5 rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-60 h-60 bg-primary-500 opacity-20 rounded-full blur-3xl"></div>

          <div className="relative z-10 flex flex-col lg:flex-row items-center gap-12">
            <div className="flex-1 space-y-6 text-center lg:text-left">
              <h2 className="text-3xl md:text-5xl font-bold mb-4">
                Have a Dream Cake in Mind?
              </h2>
              <p className="text-lg text-warm-100 max-w-xl mx-auto lg:mx-0">
                We specialize in customised designer cakes for weddings, birthdays, and special events. Share your theme, flavor preferences, and size requirements.
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 py-4">
                <div className="flex flex-col items-center lg:items-start gap-2">
                  <Palette className="text-primary-400" size={28} />
                  <span className="font-medium text-warm-50">Custom Theme</span>
                </div>
                <div className="flex flex-col items-center lg:items-start gap-2">
                  <MessageSquare className="text-primary-400" size={28} />
                  <span className="font-medium text-warm-50">Choose Flavor</span>
                </div>
                <div className="flex flex-col items-center lg:items-start gap-2">
                  <Calendar className="text-primary-400" size={28} />
                  <span className="font-medium text-warm-50">Order 2-3 days prior</span>
                </div>
              </div>

              <div className="pt-2">
                <Button onClick={handleWhatsApp} variant="primary" size="lg" className="border-2 border-transparent hover:border-white">
                  Send Details on WhatsApp
                </Button>
              </div>
            </div>

            <motion.div 
               initial={{ opacity: 0, scale: 0.8, rotate: 5 }}
               whileInView={{ opacity: 1, scale: 1, rotate: 0 }}
               viewport={{ once: true }}
               transition={{ duration: 0.8, delay: 0.2 }}
               className="flex-1 w-full max-w-md lg:max-w-lg"
            >
               <img 
                  src="https://picsum.photos/id/431/600/600" 
                  alt="Custom Designer Cake" 
                  className="rounded-2xl shadow-xl border-4 border-white/20 w-full"
                />
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default CustomOrders;