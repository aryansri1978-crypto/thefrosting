import React, { useState } from 'react';
import { MENU_DATA } from '../constants';
import { Category } from '../types';
import { ShoppingBag } from 'lucide-react';
import { WHATSAPP_NUMBER } from '../constants';
import { motion, AnimatePresence } from 'framer-motion';

const Menu: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<Category>(MENU_DATA[0].category);

  const activeItems = MENU_DATA.find(d => d.category === activeCategory)?.items || [];

  const handleOrder = (itemName: string) => {
    const text = encodeURIComponent(`Hi, I'd like to order: ${itemName}`);
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${text}`, '_blank');
  };

  return (
    <section id="menu" className="py-20 bg-warm-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-12">
          <motion.h2 
             initial={{ opacity: 0, y: 20 }}
             whileInView={{ opacity: 1, y: 0 }}
             viewport={{ once: true }}
             transition={{ duration: 0.6 }}
             className="text-3xl md:text-4xl font-bold text-warm-900 mb-4"
          >
            Explore Our Menu
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-warm-700 opacity-80"
          >
            Choose from our wide range of freshly baked delights
          </motion.p>
        </div>

        {/* Category Filters */}
        <motion.div 
           initial={{ opacity: 0, y: 20 }}
           whileInView={{ opacity: 1, y: 0 }}
           viewport={{ once: true }}
           transition={{ duration: 0.6, delay: 0.2 }}
           className="mb-10 overflow-x-auto pb-4 hide-scrollbar"
        >
          <div className="flex space-x-2 md:justify-center min-w-max px-2">
            {MENU_DATA.map((section) => (
              <button
                key={section.category}
                onClick={() => setActiveCategory(section.category)}
                className={`px-5 py-2.5 rounded-full text-sm font-medium transition-all duration-300 whitespace-nowrap ${
                  activeCategory === section.category
                    ? 'bg-primary-500 text-white shadow-lg shadow-primary-500/25 transform scale-105'
                    : 'bg-white text-warm-700 hover:bg-white/80 hover:text-primary-600 border border-transparent hover:border-primary-100'
                }`}
              >
                {section.category}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Menu Grid */}
        <motion.div 
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          <AnimatePresence mode="popLayout">
            {activeItems.map((item, index) => (
              <motion.div 
                key={item.name + index} 
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.3 }}
                className="bg-white p-6 rounded-2xl shadow-sm border border-warm-100 hover:shadow-md transition-shadow flex flex-col justify-between"
              >
                <div>
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-bold text-lg text-warm-900">{item.name}</h3>
                    <span className="font-semibold text-primary-600 bg-primary-50 px-3 py-1 rounded-full text-sm whitespace-nowrap ml-4">
                      {item.price}
                    </span>
                  </div>
                  
                  {item.description && (
                    <p className="text-sm text-gray-500 mb-3 italic">{item.description}</p>
                  )}

                  {item.subItems && (
                    <ul className="mb-4 space-y-1">
                      {item.subItems.map((sub, idx) => (
                        <li key={idx} className="text-sm text-gray-600 flex items-center">
                          <span className="w-1.5 h-1.5 bg-primary-300 rounded-full mr-2"></span>
                          {sub}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>

                <div className="mt-4 pt-4 border-t border-gray-50">
                  <button 
                    onClick={() => handleOrder(item.name)}
                    className="text-sm font-medium text-primary-600 hover:text-primary-700 flex items-center gap-2 w-full justify-end group"
                  >
                    Order on WhatsApp 
                    <ShoppingBag size={16} className="group-hover:scale-110 transition-transform"/>
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  );
};

export default Menu;