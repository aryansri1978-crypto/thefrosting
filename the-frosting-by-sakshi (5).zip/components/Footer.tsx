import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-warm-900 text-warm-100 py-12">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          
          <div className="text-center md:text-left">
            <h2 className="text-2xl font-bold text-white mb-1">The Frosting by Sakshi</h2>
            <p className="text-warm-300 text-sm">Freshly Home Baked with Love</p>
          </div>

          <div className="flex gap-8 text-sm font-medium">
            <a href="#menu" className="hover:text-primary-400 transition-colors">Menu</a>
            <a href="#specialities" className="hover:text-primary-400 transition-colors">Specialities</a>
            <a href="#contact" className="hover:text-primary-400 transition-colors">Contact</a>
          </div>

          <div className="text-warm-500 text-xs">
            © {new Date().getFullYear()} The Frosting. All rights reserved.
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;