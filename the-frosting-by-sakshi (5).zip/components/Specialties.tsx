import React from 'react';
import { Cake, Cookie, Gift, Sparkles, ChefHat, Heart } from 'lucide-react';
import { motion } from 'framer-motion';

interface SpecialtyCardProps {
  icon: any;
  title: string;
}

const SpecialtyCard: React.FC<SpecialtyCardProps> = ({ icon: Icon, title }) => (
  <div className="flex flex-col items-center justify-center p-6 bg-white rounded-2xl shadow-sm border border-warm-100 hover:shadow-md hover:border-primary-200 transition-all duration-300 group h-full">
    <div className="w-16 h-16 rounded-full bg-primary-50 flex items-center justify-center mb-4 group-hover:bg-primary-100 transition-colors">
      <Icon className="text-primary-500" size={32} />
    </div>
    <h3 className="text-center font-semibold text-warm-800 text-lg leading-tight">{title}</h3>
  </div>
);

const Specialties: React.FC = () => {
  const items = [
    { icon: Cake, title: "Customised Designer Cakes" },
    { icon: Gift, title: "Truffles, Brownies & Tea Cakes" },
    { icon: ChefHat, title: "Cupcakes & Muffins" },
    { icon: Cookie, title: "Chocolates & Cookies" },
    { icon: Sparkles, title: "Jar Cakes & Desserts" },
    { icon: Heart, title: "And many more..." },
  ];

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemAnim = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  return (
    <section id="specialities" className="py-20 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-bold text-warm-900 mb-4"
          >
            Our Specialities
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-warm-700 opacity-80"
          >
            Handcrafted with precision and the finest ingredients to make your celebrations sweeter.
          </motion.p>
        </div>

        <motion.div 
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-50px" }}
          className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 md:gap-6"
        >
          {items.map((item, index) => (
            <motion.div key={index} variants={itemAnim}>
              <SpecialtyCard icon={item.icon} title={item.title} />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Specialties;