import React from 'react';
import { Star } from 'lucide-react';
import { motion } from 'framer-motion';

interface ReviewCardProps {
  name: string;
  text: string;
}

const ReviewCard: React.FC<ReviewCardProps> = ({ name, text }) => (
  <div className="bg-white p-8 rounded-2xl shadow-sm border border-warm-100 h-full">
    <div className="flex gap-1 text-yellow-400 mb-4">
      {[...Array(5)].map((_, i) => <Star key={i} size={16} fill="currentColor" />)}
    </div>
    <p className="text-warm-700 mb-6 italic leading-relaxed">"{text}"</p>
    <div className="flex items-center gap-3">
      <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center text-primary-700 font-bold">
        {name.charAt(0)}
      </div>
      <span className="font-semibold text-warm-900">{name}</span>
    </div>
  </div>
);

const Testimonials: React.FC = () => {
  const reviews = [
    {
      name: "Anjali P.",
      text: "The most delicious Red Velvet cake I've ever had! Not too sweet, perfectly moist. The Frosting by Sakshi is now my go-to for all family birthdays."
    },
    {
      name: "Rahul M.",
      text: "Ordered the assorted brownies for a corporate gift. The packaging was elegant and the taste was premium. Everyone loved the Walnut Brownies!"
    },
    {
      name: "Sneha K.",
      text: "Absolutely loved the customization on my daughter's birthday cake. It looked exactly like the reference picture I sent and tasted heavenly."
    }
  ];

  return (
    <section className="py-20 bg-warm-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-3xl md:text-4xl font-bold text-warm-900 mb-4"
          >
            What Our Customers Say
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-warm-700 opacity-80"
          >
            Love from our happy clients
          </motion.p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {reviews.map((review, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <ReviewCard name={review.name} text={review.text} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;