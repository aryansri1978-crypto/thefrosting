import React, { useState } from 'react';
import { Phone, MessageCircle, Instagram, Copy, Check } from 'lucide-react';
import Button from './Button';
import { WHATSAPP_NUMBER, PHONE_DISPLAY, ORDER_FORMAT_TEMPLATE } from '../constants';
import { motion } from 'framer-motion';

const Contact: React.FC = () => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(ORDER_FORMAT_TEMPLATE);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCall = () => window.open(`tel:${WHATSAPP_NUMBER}`, '_self');
  const handleWhatsApp = () => window.open(`https://wa.me/${WHATSAPP_NUMBER}`, '_blank');
  
  return (
    <section id="contact" className="py-20 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20">
          
          {/* Contact Actions */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <span className="text-primary-500 font-semibold tracking-wide uppercase text-sm mb-2 block">Get in Touch</span>
            <h2 className="text-4xl font-bold text-warm-900 mb-6">Ready to Order?</h2>
            <p className="text-lg text-warm-700 mb-8 leading-relaxed">
              We are just a message away. Reach out to us for orders, queries, or just to say hi!
            </p>

            <div className="flex flex-col gap-4 mb-10">
              <div className="flex items-center gap-4 p-4 rounded-xl bg-warm-50 border border-warm-100">
                <div className="bg-primary-100 p-3 rounded-full text-primary-600">
                  <Phone size={24} />
                </div>
                <div>
                  <p className="text-sm text-gray-500">Call us at</p>
                  <p className="text-xl font-bold text-warm-900">+91 {PHONE_DISPLAY}</p>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-4">
              <Button onClick={handleCall} variant="outline" className="flex-1 sm:flex-none">
                <Phone size={18} className="mr-2" />
                Call Now
              </Button>
              <Button onClick={handleWhatsApp} className="flex-1 sm:flex-none">
                <MessageCircle size={18} className="mr-2" />
                WhatsApp Now
              </Button>
              <Button onClick={() => {}} variant="secondary" className="flex-1 sm:flex-none bg-gradient-to-tr from-purple-600 to-pink-500 border-none">
                <Instagram size={18} className="mr-2" />
                Instagram DM
              </Button>
            </div>
          </motion.div>

          {/* Order Format Box */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="bg-warm-50 rounded-2xl p-8 border border-warm-100"
          >
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-warm-900 text-lg">Order Format</h3>
              <button 
                onClick={handleCopy}
                className="text-sm flex items-center gap-1 text-primary-600 hover:text-primary-700 font-medium transition-colors"
              >
                {copied ? (
                  <>
                    <Check size={16} /> Copied
                  </>
                ) : (
                  <>
                    <Copy size={16} /> Copy
                  </>
                )}
              </button>
            </div>
            
            <div className="bg-white p-4 rounded-xl border border-warm-200 font-mono text-sm text-gray-600 leading-loose">
              {ORDER_FORMAT_TEMPLATE.split('\n').map((line, i) => (
                <div key={i}>{line}</div>
              ))}
            </div>
            
            <p className="mt-4 text-sm text-gray-500 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-primary-500"></span>
              Copy this format, fill it, and send on WhatsApp!
            </p>
          </motion.div>

        </div>
      </div>
    </section>
  );
};

export default Contact;