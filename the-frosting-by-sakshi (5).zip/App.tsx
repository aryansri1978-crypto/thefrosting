import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Specialties from './components/Specialties';
import Menu from './components/Menu';
import CustomOrders from './components/CustomOrders';
import Testimonials from './components/Testimonials';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-white font-sans text-warm-900 selection:bg-primary-100 selection:text-primary-900">
      <Header />
      <main>
        <Hero />
        <Specialties />
        <Menu />
        <CustomOrders />
        <Testimonials />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;