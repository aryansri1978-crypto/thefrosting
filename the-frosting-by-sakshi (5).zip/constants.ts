import { MenuCategoryData } from './types';

export const WHATSAPP_NUMBER = "918934935910";
export const PHONE_DISPLAY = "8934935910";

export const ORDER_FORMAT_TEMPLATE = `Name:
Delivery date:
Items:
Flavour:
Quantity:
Address (if needed):`;

export const MENU_DATA: MenuCategoryData[] = [
  {
    category: "Cake Flavours",
    items: [
      { name: "Vanilla", price: "₹399" },
      { name: "Pineapple", price: "₹399" },
      { name: "Black Forest", price: "₹399" },
      { name: "Strawberry", price: "₹399" },
      { name: "Butterscotch", price: "₹399" },
      { name: "Coffee Cake", price: "₹399" },
      { name: "Chocolate", price: "₹449" },
      { name: "Blueberry", price: "₹499" },
      { name: "Coffee Mousse Cake", price: "₹449" },
      { name: "Chocolate Mousse", price: "₹499" },
      { name: "Chocolate Truffle", price: "₹499" },
    ]
  },
  {
    category: "Premium Cakes",
    items: [
      { name: "Rasmalai", price: "₹549" },
      { name: "Lemon Blueberry", price: "₹549" },
      { name: "Red Velvet", price: "₹599" },
      { name: "Lotus Biscoff", price: "₹649" },
    ]
  },
  {
    category: "Bento Cake",
    items: [
      { name: "Bento Cake (Any flavour)", price: "₹179" },
      { name: "Chocolate Bento", price: "₹199" },
    ]
  },
  {
    category: "Jar Cakes",
    items: [
      { name: "Pineapple / Black Forest / Chocolate", price: "₹179" },
      { name: "Blueberry / Rasmalai", price: "₹199" },
      { name: "Lotus Biscoff", price: "₹229" },
    ]
  },
  {
    category: "Cupcakes",
    items: [
      { name: "Set of 6 cupcakes", price: "₹249" },
    ]
  },
  {
    category: "Cookies",
    items: [
      { name: "Chocochip Cookie", price: "₹120" },
      { name: "Double Chocolate Cookie", price: "₹129" },
      { name: "Triple Chocolate Cookie", price: "₹149" },
      { name: "Naankhatai", price: "₹179", description: "Made with homemade desi ghee" },
    ]
  },
  {
    category: "Chocolate Fun",
    items: [
      { name: "Customised Chocolate Bar", price: "₹249" },
      { name: "Bar with nuts", price: "₹299" },
      { name: "Flavoured chocolate", price: "₹349" },
      { name: "Chocolate cube", price: "₹5 each" },
    ]
  },
  {
    category: "Brownies",
    items: [
      { name: "Fudge brownie", price: "₹299" },
      { name: "Walnut brownie", price: "₹399" },
      { name: "Brookies", price: "₹399" },
      { name: "Hazelnut Brownie", price: "₹449" },
      { name: "Lotus Biscoff Brownie", price: "₹449" },
      { name: "Assorted Brownie", price: "₹499" },
      { name: "Double Chocolate Brownie", price: "₹499" },
      { name: "Double Chocolate Brownie with nuts (any nut)", price: "₹549" },
    ]
  },
  {
    category: "Truffles",
    items: [
      { 
        name: "Pack of 6 truffles", 
        price: "₹180",
        subItems: [
          "Plain chocolate truffles",
          "Mint Flavour",
          "Pina Colada",
          "Paan Flavour",
          "Gulkand Flavour"
        ]
      },
    ]
  },
  {
    category: "Truffles with Nuts",
    items: [
      { 
        name: "Pack of 6", 
        price: "₹249",
        subItems: [
          "Mocha Walnut",
          "Pistachio",
          "Kaju Katli",
          "Lemon cheesecake truffle"
        ]
      },
    ]
  },
  {
    category: "Tea Cakes",
    items: [
      { name: "Tuty Fruty cake", price: "₹399" },
      { name: "Paan Cake", price: "₹399" },
      { name: "Atta Jaggery Cake", price: "₹449" },
      { name: "Ragi Banana cake", price: "₹449" },
      { name: "Orange Delight Cake", price: "₹449" },
      { name: "Loaf Orange Tea cake", price: "₹449" },
      { name: "Masala Chai Cake", price: "₹499" },
      { name: "Belgium chocolate cake", price: "₹499" },
      { name: "Classic Dates & Walnut cake", price: "₹499" },
      { name: "Lemon white chocolate cake", price: "₹549" },
    ]
  },
];