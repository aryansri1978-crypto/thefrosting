export type Category = 
  | "Cake Flavours"
  | "Premium Cakes"
  | "Bento Cake"
  | "Jar Cakes"
  | "Cupcakes"
  | "Cookies"
  | "Chocolate Fun"
  | "Brownies"
  | "Truffles"
  | "Truffles with Nuts"
  | "Tea Cakes";

export interface MenuItem {
  name: string;
  price: string;
  description?: string;
  subItems?: string[];
}

export interface MenuCategoryData {
  category: Category;
  items: MenuItem[];
}